#!/usr/bin/env bash
# Starts Waybar with the right workspace module for the running compositor.
# niri -> niri/workspaces | Hyprland -> hyprland/workspaces | mango -> dwl/tags

CFG_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/waybar"
TMP_CFG="${XDG_RUNTIME_DIR:-/tmp}/waybar-config.json"
DESKTOP="$(printf '%s' "${XDG_CURRENT_DESKTOP:-}${XDG_SESSION_DESKTOP:-}" | tr '[:upper:]' '[:lower:]')"

if [ -n "${NIRI_SOCKET:-}" ] || [[ "$DESKTOP" == *niri* ]]; then
  WS="niri/workspaces"
elif [ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ] || [[ "$DESKTOP" == *hypr* ]]; then
  WS="hyprland/workspaces"
elif [[ "$DESKTOP" == *mango* ]] || pgrep -x mango >/dev/null 2>&1; then
  WS="dwl/tags"
else
  echo "waybar-launch: compositor not detected, falling back to dwl/tags" >&2
  WS="dwl/tags"
fi

jq --arg ws "$WS" '.["modules-center"] = [$ws]' "$CFG_DIR/config.json" > "$TMP_CFG"

pkill -x waybar 2>/dev/null
sleep 0.2
exec waybar -c "$TMP_CFG" -s "$CFG_DIR/style.css"
