#!/usr/bin/env bash
# Power menu for the Waybar logout button. Works on niri, Hyprland and mango.
THEME="${XDG_CONFIG_HOME:-$HOME/.config}/rofi/launcher.rasi"

choice="$(printf '%s\n' Lock Logout Suspend Reboot Shutdown | \
  rofi -dmenu -i -p "Power" -theme "$THEME" \
  -theme-str 'window { width: 320px; } listview { lines: 5; }')"

case "$choice" in
  Lock)
    for l in hyprlock swaylock gtklock; do
      command -v "$l" >/dev/null && { exec "$l"; }
    done ;;
  Logout)
    if [ -n "${XDG_SESSION_ID:-}" ]; then
      loginctl terminate-session "$XDG_SESSION_ID"
    else
      loginctl terminate-user "$USER"
    fi ;;
  Suspend)  systemctl suspend ;;
  Reboot)   systemctl reboot ;;
  Shutdown) systemctl poweroff ;;
esac
