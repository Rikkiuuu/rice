#!/usr/bin/env bash
# Rofi wallpaper picker. Backends: awww, swaybg, hyprpaper (Hyprland only).
#   wallpaper-picker.sh            open the picker
#   wallpaper-picker.sh --random   set a random wallpaper
#   wallpaper-picker.sh --restore  re-apply last wallpaper (use on startup)
# Env: WALLPAPER_DIR (default ~/Pictures/Wallpapers), WALLPAPER_BACKEND (override)

WALL_DIR="${WALLPAPER_DIR:-$HOME/Pictures/Wallpapers}"
CACHE="${XDG_CACHE_HOME:-$HOME/.cache}/wallpaper-picker"
THUMBS="$CACHE/thumbs"
STATE="$CACHE/current"
THEME="${XDG_CONFIG_HOME:-$HOME/.config}/rofi/wallpaper.rasi"
mkdir -p "$THUMBS"

detect_backend() {
  [ -n "${WALLPAPER_BACKEND:-}" ] && { echo "$WALLPAPER_BACKEND"; return; }
  if command -v awww >/dev/null; then echo awww
  elif command -v swaybg >/dev/null; then echo swaybg
  elif command -v hyprpaper >/dev/null && [ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ]; then echo hyprpaper
  else echo none; fi
}

set_wall() {
  local img="$1"
  [ -f "$img" ] || { echo "not a file: $img" >&2; return 1; }
  case "$(detect_backend)" in
    awww)
      pgrep -x awww-daemon >/dev/null || { setsid awww-daemon >/dev/null 2>&1 & sleep 0.6; }
      awww img "$img" --transition-type grow --transition-duration 1.2 --transition-fps 60
      ;;
    swaybg)
      pkill -x swaybg 2>/dev/null
      setsid swaybg -i "$img" -m fill >/dev/null 2>&1 &
      ;;
    hyprpaper)
      pgrep -x hyprpaper >/dev/null || { setsid hyprpaper >/dev/null 2>&1 & sleep 1; }
      hyprctl hyprpaper preload "$img" >/dev/null 2>&1
      hyprctl hyprpaper wallpaper ",$img" >/dev/null 2>&1
      ;;
    *)
      echo "No wallpaper backend found (install awww, swaybg or hyprpaper)" >&2
      return 1
      ;;
  esac
  printf '%s' "$img" > "$STATE"
}

mapfile -t FILES < <(find -L "$WALL_DIR" -type f \
  \( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' -o -iname '*.webp' -o -iname '*.gif' \) | sort)

case "${1:-}" in
  --restore)
    [ -f "$STATE" ] && set_wall "$(cat "$STATE")"
    exit 0 ;;
  --random)
    [ "${#FILES[@]}" -gt 0 ] && set_wall "${FILES[RANDOM % ${#FILES[@]}]}"
    exit 0 ;;
esac

if [ "${#FILES[@]}" -eq 0 ]; then
  notify-send "Wallpaper picker" "No images in $WALL_DIR" 2>/dev/null
  echo "No images in $WALL_DIR" >&2
  exit 1
fi

thumb_for() {
  local f="$1" t
  t="$THUMBS/$(printf '%s' "$f" | md5sum | cut -d' ' -f1).png"
  if [ ! -f "$t" ]; then
    if command -v magick >/dev/null; then
      magick "${f}[0]" -resize 400x225^ -gravity center -extent 400x225 "$t" 2>/dev/null
    elif command -v convert >/dev/null; then
      convert "${f}[0]" -resize 400x225^ -gravity center -extent 400x225 "$t" 2>/dev/null
    fi
  fi
  [ -f "$t" ] && echo "$t" || echo "$f"
}

menu() {
  printf '%s\0icon\x1f%s\n' "  Random Wallpaper" "$(thumb_for "${FILES[0]}")"
  for f in "${FILES[@]}"; do
    printf '%s\0icon\x1f%s\n' "$(basename "$f")" "$(thumb_for "$f")"
  done
}

idx="$(menu | rofi -dmenu -i -show-icons -format i -p "Select Wallpaper" -theme "$THEME")"
[ -z "$idx" ] && exit 0

if [ "$idx" -eq 0 ]; then
  set_wall "${FILES[RANDOM % ${#FILES[@]}]}"
else
  set_wall "${FILES[$((idx - 1))]}"
fi
