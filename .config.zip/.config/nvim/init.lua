-- ~/.config/nvim/init.lua
-- Single-file Neovim config. Needs Neovim 0.11+.
--
-- Design:
--   * Native LSP (vim.lsp.config / vim.lsp.enable), no Mason, so it works the same
--     on Arch and NixOS: install language servers with pacman / nix.
--   * Only servers found in $PATH are enabled, so missing ones never throw errors.
--   * Small plugin set, lazy-loaded, starts fast on a 4GB laptop.
--
-- External tools: git, gcc, tree-sitter-cli, ripgrep, fd, fzf
-- Formatters (optional): stylua, ruff, shfmt, prettier, nixfmt

vim.g.mapleader = " "
vim.g.maplocalleader = "\\"

-- Unused providers slow startup
for _, p in ipairs({ "perl", "ruby", "node", "python3" }) do
  vim.g["loaded_" .. p .. "_provider"] = 0
end

---------------------------------------------------------------------------
-- Options
---------------------------------------------------------------------------
local o = vim.opt

o.number = true
o.relativenumber = true
o.signcolumn = "yes"
o.cursorline = true
o.scrolloff = 8
o.sidescrolloff = 8
o.wrap = false
o.termguicolors = true
o.showmode = false
o.laststatus = 3
o.winborder = "rounded"
o.pumheight = 10
o.list = true
o.listchars = { tab = "» ", trail = "·", nbsp = "␣" }
o.fillchars = { eob = " " }

o.mouse = "a"
o.ignorecase = true
o.smartcase = true
o.inccommand = "split"
o.splitright = true
o.splitbelow = true
o.confirm = true
o.grepprg = "rg --vimgrep --smart-case"

o.expandtab = true
o.shiftwidth = 2
o.tabstop = 2
o.smartindent = true

o.undofile = true
o.swapfile = false
o.updatetime = 200
o.timeoutlen = 300

o.completeopt = { "menu", "menuone", "noselect" }

o.foldmethod = "expr"
o.foldexpr = "v:lua.vim.treesitter.foldexpr()"
o.foldlevelstart = 99

-- Clipboard sync is slow at startup; set it after the UI is up
vim.schedule(function()
  o.clipboard = "unnamedplus"
end)

---------------------------------------------------------------------------
-- Keymaps
---------------------------------------------------------------------------
local map = vim.keymap.set

map("n", "<Esc>", "<cmd>nohlsearch<cr>", { desc = "Clear search highlight" })

-- Wrapped lines behave like real lines
map({ "n", "x" }, "j", "v:count == 0 ? 'gj' : 'j'", { expr = true })
map({ "n", "x" }, "k", "v:count == 0 ? 'gk' : 'k'", { expr = true })

-- Keep selection while indenting, move selected lines
map("v", "<", "<gv")
map("v", ">", ">gv")
map("v", "J", ":m '>+1<cr>gv=gv", { desc = "Move line down" })
map("v", "K", ":m '<-2<cr>gv=gv", { desc = "Move line up" })

-- Centered scrolling and searching
map("n", "<C-d>", "<C-d>zz")
map("n", "<C-u>", "<C-u>zz")
map("n", "n", "nzzzv")
map("n", "N", "Nzzzv")

-- Windows
map("n", "<C-h>", "<C-w>h", { desc = "Window left" })
map("n", "<C-j>", "<C-w>j", { desc = "Window down" })
map("n", "<C-k>", "<C-w>k", { desc = "Window up" })
map("n", "<C-l>", "<C-w>l", { desc = "Window right" })

-- Paste over a selection without losing the yank
map("x", "<leader>p", [["_dP]], { desc = "Paste without yanking" })

map("n", "<leader>w", "<cmd>w<cr>", { desc = "Save" })
map("n", "<leader>q", "<cmd>qa<cr>", { desc = "Quit all" })
map("n", "<leader>bd", "<cmd>bdelete<cr>", { desc = "Delete buffer" })
map("t", "<Esc><Esc>", [[<C-\><C-n>]], { desc = "Leave terminal mode" })

---------------------------------------------------------------------------
-- Autocmds
---------------------------------------------------------------------------
local function augroup(name)
  return vim.api.nvim_create_augroup("user_" .. name, { clear = true })
end

vim.api.nvim_create_autocmd("TextYankPost", {
  group = augroup("yank"),
  callback = function()
    vim.hl.on_yank()
  end,
})

vim.api.nvim_create_autocmd("BufReadPost", {
  group = augroup("last_pos"),
  callback = function(ev)
    local mark = vim.api.nvim_buf_get_mark(ev.buf, '"')
    local lines = vim.api.nvim_buf_line_count(ev.buf)
    if mark[1] > 0 and mark[1] <= lines then
      pcall(vim.api.nvim_win_set_cursor, 0, mark)
    end
  end,
})

vim.api.nvim_create_autocmd("VimResized", {
  group = augroup("resize"),
  callback = function()
    vim.cmd("tabdo wincmd =")
  end,
})

vim.api.nvim_create_autocmd({ "FocusGained", "TermClose", "TermLeave" }, {
  group = augroup("checktime"),
  command = "checktime",
})

vim.api.nvim_create_autocmd("FileType", {
  group = augroup("close_with_q"),
  pattern = { "help", "qf", "man", "checkhealth", "lspinfo" },
  callback = function(ev)
    vim.bo[ev.buf].buflisted = false
    map("n", "q", "<cmd>close<cr>", { buffer = ev.buf, silent = true })
  end,
})

vim.api.nvim_create_autocmd("FileType", {
  group = augroup("indent"),
  pattern = { "rust", "c", "cpp", "java" },
  callback = function()
    vim.bo.shiftwidth = 4
    vim.bo.tabstop = 4
  end,
})

vim.api.nvim_create_autocmd("FileType", {
  group = augroup("go"),
  pattern = "go",
  callback = function()
    vim.bo.expandtab = false
    vim.bo.shiftwidth = 4
    vim.bo.tabstop = 4
  end,
})

vim.api.nvim_create_autocmd("TermOpen", {
  group = augroup("term"),
  callback = function()
    vim.opt_local.number = false
    vim.opt_local.relativenumber = false
    vim.opt_local.signcolumn = "no"
    vim.cmd.startinsert()
  end,
})

-- :FormatToggle (global) and :FormatToggle! (current buffer only)
vim.api.nvim_create_user_command("FormatToggle", function(args)
  if args.bang then
    vim.b.disable_autoformat = not vim.b.disable_autoformat
  else
    vim.g.disable_autoformat = not vim.g.disable_autoformat
  end
end, { bang = true, desc = "Toggle format on save (! = this buffer only)" })

---------------------------------------------------------------------------
-- Diagnostics
---------------------------------------------------------------------------
vim.diagnostic.config({
  severity_sort = true,
  update_in_insert = false,
  underline = { severity = vim.diagnostic.severity.WARN },
  virtual_text = { spacing = 2, source = "if_many" },
  float = { border = "rounded", source = "if_many" },
  signs = {
    text = {
      [vim.diagnostic.severity.ERROR] = "E",
      [vim.diagnostic.severity.WARN] = "W",
      [vim.diagnostic.severity.INFO] = "I",
      [vim.diagnostic.severity.HINT] = "H",
    },
  },
})

---------------------------------------------------------------------------
-- Plugins (lazy.nvim)
---------------------------------------------------------------------------
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not (vim.uv or vim.loop).fs_stat(lazypath) then
  local out = vim.fn.system({
    "git", "clone", "--filter=blob:none", "--branch=stable",
    "https://github.com/folke/lazy.nvim.git", lazypath,
  })
  if vim.v.shell_error ~= 0 then
    error("Failed to clone lazy.nvim:\n" .. out)
  end
end
vim.opt.rtp:prepend(lazypath)

require("lazy").setup({
  spec = {
    -- Colorscheme ---------------------------------------------------------
    {
      "catppuccin/nvim",
      name = "catppuccin",
      priority = 1000,
      opts = {
        flavour = "mocha",
        transparent_background = true, -- terminal opacity/blur shows through
        integrations = {
          blink_cmp = true,
          gitsigns = true,
          mini = { enabled = true },
          which_key = true,
          treesitter = true,
          fzf = true,
        },
      },
      config = function(_, opts)
        require("catppuccin").setup(opts)
        vim.cmd.colorscheme("catppuccin")
      end,
    },

    -- Treesitter (main branch: needs tree-sitter-cli and a C compiler) ----
    {
      "nvim-treesitter/nvim-treesitter",
      branch = "main",
      lazy = false,
      build = ":TSUpdate",
      config = function()
        local ts = require("nvim-treesitter")
        ts.setup()
        ts.install({
          "bash", "c", "cpp", "css", "diff", "go", "html", "hyprlang",
          "javascript", "json", "kdl", "lua", "luadoc", "markdown",
          "markdown_inline", "nix", "python", "query", "regex", "rust",
          "toml", "tsx", "typescript", "vim", "vimdoc", "yaml",
        })
        vim.api.nvim_create_autocmd("FileType", {
          group = augroup("treesitter"),
          callback = function(ev)
            if pcall(vim.treesitter.start, ev.buf) then
              vim.bo[ev.buf].indentexpr = "v:lua.require'nvim-treesitter'.indentexpr()"
            end
          end,
        })
      end,
    },

    -- LSP configs (data only; servers are enabled below) ------------------
    { "neovim/nvim-lspconfig" },

    -- Neovim Lua API completion for editing this config -------------------
    {
      "folke/lazydev.nvim",
      ft = "lua",
      opts = {
        library = { { path = "${3rd}/luv/library", words = { "vim%.uv" } } },
      },
    },

    -- Completion ----------------------------------------------------------
    {
      "saghen/blink.cmp",
      version = "1.*",
      dependencies = { "rafamadriz/friendly-snippets" },
      opts = {
        keymap = { preset = "default" }, -- <C-space> open, <C-y> accept, <C-n>/<C-p> select
        appearance = { nerd_font_variant = "mono" },
        completion = {
          documentation = { auto_show = true, auto_show_delay_ms = 300 },
          menu = {
            border = "none",
            draw = {
              -- label on the left; kind icon, kind name and [source] on the right
              columns = {
                { "label", "label_description", gap = 1 },
                { "kind_icon", "kind", "source_name", gap = 1 },
              },
              components = {
                source_name = {
                  text = function(ctx)
                    return "[" .. ctx.source_name .. "]"
                  end,
                },
              },
            },
          },
        },
        signature = { enabled = true },
        sources = {
          default = { "lsp", "path", "snippets", "buffer" },
          per_filetype = { lua = { inherit_defaults = true, "lazydev" } },
          providers = {
            lazydev = {
              name = "LazyDev",
              module = "lazydev.integrations.blink",
              score_offset = 100,
            },
          },
        },
      },
    },

    -- Formatting ----------------------------------------------------------
    {
      "stevearc/conform.nvim",
      event = "BufWritePre",
      cmd = "ConformInfo",
      keys = {
        {
          "<leader>cf",
          function()
            require("conform").format({ async = true })
          end,
          mode = { "n", "v" },
          desc = "Format",
        },
      },
      opts = {
        formatters_by_ft = {
          lua = { "stylua" },
          python = { "ruff_organize_imports", "ruff_format" },
          nix = { "nixfmt" },
          sh = { "shfmt" },
          bash = { "shfmt" },
          javascript = { "prettier" },
          typescript = { "prettier" },
          javascriptreact = { "prettier" },
          typescriptreact = { "prettier" },
          css = { "prettier" },
          html = { "prettier" },
          json = { "prettier" },
          yaml = { "prettier" },
        },
        default_format_opts = { lsp_format = "fallback" },
        format_on_save = function(bufnr)
          if vim.g.disable_autoformat or vim.b[bufnr].disable_autoformat then
            return
          end
          return { timeout_ms = 800 }
        end,
      },
    },

    -- Fuzzy finder (light; needs fzf + ripgrep) ---------------------------
    {
      "ibhagwan/fzf-lua",
      cmd = "FzfLua",
      opts = { "max-perf" },
      keys = {
        { "<leader><space>", function() require("fzf-lua").files() end, desc = "Find files" },
        { "<leader>/", function() require("fzf-lua").live_grep() end, desc = "Grep project" },
        { "<leader>,", function() require("fzf-lua").buffers() end, desc = "Buffers" },
        { "<leader>fr", function() require("fzf-lua").oldfiles() end, desc = "Recent files" },
        { "<leader>fh", function() require("fzf-lua").helptags() end, desc = "Help" },
        { "<leader>fk", function() require("fzf-lua").keymaps() end, desc = "Keymaps" },
        { "<leader>fd", function() require("fzf-lua").diagnostics_document() end, desc = "Diagnostics" },
        { "<leader>fs", function() require("fzf-lua").lsp_document_symbols() end, desc = "Symbols" },
        { "<leader>fw", function() require("fzf-lua").grep_cword() end, desc = "Word under cursor" },
        {
          "<leader>fc",
          function() require("fzf-lua").files({ cwd = vim.fn.stdpath("config") }) end,
          desc = "Neovim config",
        },
      },
    },

    -- File explorer as a buffer: edit the filesystem like text ------------
    {
      "stevearc/oil.nvim",
      lazy = false,
      keys = { { "-", "<cmd>Oil<cr>", desc = "Open parent directory" } },
      opts = {
        default_file_explorer = false, -- nvim-tree handles `nvim .`; oil stays on `-`
        view_options = { show_hidden = true },
        skip_confirm_for_simple_edits = true,
      },
    },

    -- File tree on the left, git markers (✗) and colored names ------------
    {
      "nvim-tree/nvim-tree.lua",
      lazy = false, -- so `nvim .` opens the tree
      keys = {
        { "<leader>e", "<cmd>NvimTreeToggle<cr>", desc = "File tree" },
        { "<leader>E", "<cmd>NvimTreeFindFile<cr>", desc = "Reveal current file in tree" },
      },
      opts = {
        view = { width = 32 },
        update_focused_file = { enable = true },
        git = { enable = true, ignore = false },
        renderer = {
          highlight_git = "name",
          root_folder_label = ":~:s?$?/..?",
          indent_markers = { enable = true },
        },
      },
    },

    -- Tab bar with file icons and close buttons -----------------------------
    {
      "akinsho/bufferline.nvim",
      version = "*",
      event = "VeryLazy",
      keys = {
        { "<S-l>", "<cmd>BufferLineCycleNext<cr>", desc = "Next buffer" },
        { "<S-h>", "<cmd>BufferLineCyclePrev<cr>", desc = "Previous buffer" },
        { "<leader>bp", "<cmd>BufferLinePick<cr>", desc = "Pick buffer" },
      },
      opts = {
        options = {
          separator_style = "thin",
          diagnostics = "nvim_lsp",
          always_show_bufferline = true,
          offsets = {
            { filetype = "NvimTree", text = "", highlight = "Directory", separator = true },
          },
        },
      },
    },

    -- Git -----------------------------------------------------------------
    {
      "lewis6991/gitsigns.nvim",
      event = { "BufReadPost", "BufNewFile" },
      opts = {
        on_attach = function(buf)
          local gs = require("gitsigns")
          local function m(lhs, rhs, desc)
            vim.keymap.set("n", lhs, rhs, { buffer = buf, desc = desc })
          end
          m("]h", function() gs.nav_hunk("next") end, "Next hunk")
          m("[h", function() gs.nav_hunk("prev") end, "Previous hunk")
          m("<leader>hp", gs.preview_hunk, "Preview hunk")
          m("<leader>hs", gs.stage_hunk, "Stage hunk")
          m("<leader>hr", gs.reset_hunk, "Reset hunk")
          m("<leader>hb", function() gs.blame_line({ full = true }) end, "Blame line")
        end,
      },
    },

    -- Small quality-of-life modules: icons, pairs, surround, textobjects, statusline
    {
      "nvim-mini/mini.nvim",
      lazy = false,
      config = function()
        require("mini.icons").setup()
        MiniIcons.mock_nvim_web_devicons()
        require("mini.pairs").setup()
        require("mini.surround").setup() -- sa/sd/sr + motion
        require("mini.ai").setup({ n_lines = 500 })
        require("mini.statusline").setup({ use_icons = true })
      end,
    },

    -- Keymap hints --------------------------------------------------------
    {
      "folke/which-key.nvim",
      event = "VeryLazy",
      opts = {
        preset = "helix",
        spec = {
          { "<leader>f", group = "find" },
          { "<leader>c", group = "code" },
          { "<leader>h", group = "git hunks" },
          { "<leader>b", group = "buffer" },
        },
      },
    },
  },

  install = { colorscheme = { "catppuccin", "habamax" } },
  checker = { enabled = false },
  change_detection = { notify = false },
  performance = {
    rtp = {
      disabled_plugins = { "gzip", "netrwPlugin", "tarPlugin", "tohtml", "tutor", "zipPlugin" },
    },
  },
})

---------------------------------------------------------------------------
-- LSP (native). Only servers present in $PATH are enabled.
-- Defaults in 0.11: grn rename, gra code action, grr references,
-- gri implementation, grt type definition, gO symbols, K hover, <C-s> signature.
---------------------------------------------------------------------------
local ok_blink, blink = pcall(require, "blink.cmp")
if ok_blink then
  vim.lsp.config("*", { capabilities = blink.get_lsp_capabilities() })
end

vim.lsp.config("lua_ls", {
  settings = {
    Lua = {
      runtime = { version = "LuaJIT" },
      diagnostics = { globals = { "vim" } },
      completion = { callSnippet = "Replace" },
      telemetry = { enable = false },
    },
  },
})

-- server name -> executable
local servers = {
  lua_ls = "lua-language-server",
  nixd = "nixd",
  basedpyright = "basedpyright-langserver",
  clangd = "clangd",
  rust_analyzer = "rust-analyzer",
  gopls = "gopls",
  bashls = "bash-language-server",
  ts_ls = "typescript-language-server",
  jsonls = "vscode-json-language-server",
  taplo = "taplo",
  marksman = "marksman",
}

for name, exe in pairs(servers) do
  if vim.fn.executable(exe) == 1 then
    vim.lsp.enable(name)
  end
end

vim.api.nvim_create_autocmd("LspAttach", {
  group = augroup("lsp_attach"),
  callback = function(ev)
    local function bmap(lhs, rhs, desc)
      map("n", lhs, rhs, { buffer = ev.buf, desc = desc })
    end
    bmap("gd", vim.lsp.buf.definition, "Go to definition")
    bmap("gD", vim.lsp.buf.declaration, "Go to declaration")
    bmap("<leader>ih", function()
      local on = vim.lsp.inlay_hint.is_enabled({ bufnr = ev.buf })
      vim.lsp.inlay_hint.enable(not on, { bufnr = ev.buf })
    end, "Toggle inlay hints")
    bmap("<leader>cd", vim.diagnostic.open_float, "Line diagnostics")
  end,
})
