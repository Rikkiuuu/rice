-- Misc behavior: focus, snapping, dragging

hl.config({
    general = {
        no_focus_fallback = true, -- focus_cross_monitor=0
        snap = {
            enabled    = false,   -- enable_floating_snap=0
            window_gap = 30,      -- snap_distance
        },
    },

    misc = {
        focus_on_activate = true,
    },
})
