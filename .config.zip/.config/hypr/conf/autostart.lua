-- Autostart (mango: exec_once=noctalia)

hl.monitor({
    output   = "",
    mode     = "preferred",
    position = "auto",
    scale    = "auto",
})

hl.env("XCURSOR_SIZE", "24")
hl.env("HYPRCURSOR_SIZE", "24")

hl.on("hyprland.start", function()
    hl.exec_cmd("noctalia")
    -- If your Noctalia v4 is launched through Quickshell, use this instead:
    -- hl.exec_cmd("qs -c noctalia-shell")
end)
