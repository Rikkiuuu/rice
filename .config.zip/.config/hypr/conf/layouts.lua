-- Layouts. mango "tile" = master-stack, "scroller" = scrolling.
-- Default is master on every workspace; SUPER+N cycles layouts (see binds.lua).

hl.config({
    general = { layout = "master" },

    master = {
        new_status = "master", -- new_is_master=1
        mfact      = 0.55,     -- default_master_factor
    },

    scrolling = {
        column_width             = 0.8,                -- scroller_default_proportion
        explicit_column_widths   = "0.5, 0.8, 1.0",    -- scroller_proportion_preset
        fullscreen_on_one_column = true,
    },

    dwindle = {
        preserve_split = false,
        smart_split    = false,
    },
})

-- tag_num=9: keep nine workspaces around
for i = 1, 9 do
    hl.workspace_rule({ workspace = tostring(i), persistent = true })
end
