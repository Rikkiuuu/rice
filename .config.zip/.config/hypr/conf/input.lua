-- Input devices

hl.config({
    input = {
        kb_layout            = "us",
        repeat_rate          = 25,
        repeat_delay         = 600,
        numlock_by_default   = false,

        follow_mouse         = 1,      -- sloppy_focus
        sensitivity          = 0,
        natural_scroll       = false,  -- mouse_natural_scrolling
        left_handed          = false,
    },

    cursor = {
        warp_on_change_workspace = 1,  -- warp_cursor
    },
})

-- Trackpad. Option names with dashes differ between versions, so try both spellings.
local touchpad_common = {
    natural_scroll          = false,
    disable_while_typing    = true,
    middle_button_emulation = false,
    drag_lock               = true,
}
local a = { ["tap-to-click"] = true, ["tap-and-drag"] = true }
local b = { tap_to_click = true,     tap_and_drag = true }
for k, v in pairs(touchpad_common) do a[k] = v; b[k] = v end

if not pcall(hl.config, { input = { touchpad = a } }) then
    pcall(hl.config, { input = { touchpad = b } })
end

-- 4-finger swipe switches workspaces (mango: viewprev/viewnext)
pcall(hl.gesture, { fingers = 4, direction = "horizontal", action = "workspace" })
