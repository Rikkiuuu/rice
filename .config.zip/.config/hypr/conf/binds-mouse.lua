-- Mouse and scroll bindings

hl.bind("SUPER + mouse:272", hl.dsp.window.drag(),   { mouse = true })  -- move
hl.bind("SUPER + mouse:273", hl.dsp.window.resize(), { mouse = true })  -- resize

-- SUPER + scroll switches tags that have windows
hl.bind("SUPER + mouse_up",   hl.dsp.focus({ workspace = "e-1" }))
hl.bind("SUPER + mouse_down", hl.dsp.focus({ workspace = "e+1" }))
