-- Appearance: gaps, borders, colors
-- mango inner gap 6 = gaps_in 3 on each side of a window, outer 12 stays 12.

hl.config({
    general = {
        gaps_in     = 3,
        gaps_out    = 12,
        border_size = 3,

        col = {
            active_border   = "rgba(c9b890ff)", -- focus_color
            inactive_border = "rgba(444444ff)", -- border_color
        },

        resize_on_border = false,
        allow_tearing    = false,
    },

    misc = {
        force_default_wallpaper = 0,
        disable_hyprland_logo   = true,
        background_color        = 0xff201b14, -- root_color
    },
})
