-- Key bindings. Same mods as mango: ALT = window actions, SUPER = system/tags, CTRL = view tag.

local terminal = "foot"
local menu     = "rofi -show drun"

local dirs = { Left = "left", Right = "right", Up = "up", Down = "down" }

-- reload / apps / exit
hl.bind("SUPER + r",     hl.dsp.exec_cmd("hyprctl reload"))
hl.bind("ALT + space",   hl.dsp.exec_cmd(menu))
hl.bind("ALT + Return",  hl.dsp.exec_cmd(terminal))
hl.bind("SUPER + m",     hl.dsp.exit())
hl.bind("ALT + q",       hl.dsp.window.close())

-- focus / move window
hl.bind("SUPER + Tab", function()
    hl.dispatch(hl.dsp.window.cycle_next())
    hl.dispatch(hl.dsp.window.bring_to_top())
end)

for key, d in pairs(dirs) do
    hl.bind("ALT + " .. key,           hl.dsp.focus({ direction = d }))
    hl.bind("SUPER + SHIFT + " .. key, hl.dsp.window.move({ direction = d }))
end

-- window state
hl.bind("SUPER + g",           hl.dsp.window.pin())                                               -- toggleglobal
hl.bind("ALT + Tab",           hl.dsp.focus({ last = true }))                                     -- togglejump
hl.bind("ALT + backslash",     hl.dsp.window.float({ action = "toggle" }))
hl.bind("ALT + a",             hl.dsp.window.fullscreen({ mode = "maximized",  action = "toggle" }))
hl.bind("ALT + f",             hl.dsp.window.fullscreen({ mode = "fullscreen", action = "toggle" }))

-- minimize = park in a special workspace
hl.bind("SUPER + i", hl.dsp.window.move({ workspace = "special:minimize", follow = false }))
hl.bind("SUPER + SHIFT + i", function()
    hl.dispatch(hl.dsp.workspace.toggle_special("minimize"))
    hl.dispatch(hl.dsp.window.move({ workspace = "+0" }))
    hl.dispatch(hl.dsp.workspace.toggle_special("minimize"))
end)

-- scratchpad
hl.bind("ALT + z",     hl.dsp.workspace.toggle_special("scratchpad"))
hl.bind("SUPER + z",   hl.dsp.window.move({ workspace = "special:scratchpad", follow = false })) -- extra: send to scratchpad

-- scroller layout
hl.bind("ALT + e",     hl.dsp.layout("colresize 1.0"))
hl.bind("ALT + x",     hl.dsp.layout("colresize +conf"))
hl.bind("ALT + SUPER + CTRL + Left",  hl.dsp.layout("movewindowto l"))
hl.bind("ALT + SUPER + CTRL + Right", hl.dsp.layout("movewindowto r"))
hl.bind("ALT + SUPER + CTRL + Up",    hl.dsp.layout("movewindowto u"))
hl.bind("ALT + SUPER + CTRL + Down",  hl.dsp.layout("movewindowto d"))

-- dwindle layout
hl.bind("ALT + SHIFT + Return", hl.dsp.layout("togglesplit"))

-- switch layout (mango order: tile first)
local layouts, idx = { "master", "scrolling", "dwindle", "monocle" }, 1
hl.bind("SUPER + n", function()
    idx = idx % #layouts + 1
    hl.config({ general = { layout = layouts[idx] } })
end)

-- tag (workspace) switch
hl.bind("SUPER + Left",        hl.dsp.focus({ workspace = "-1" }))
hl.bind("SUPER + Right",       hl.dsp.focus({ workspace = "+1" }))
hl.bind("CTRL + Left",         hl.dsp.focus({ workspace = "e-1" }))   -- _have_client = only used workspaces
hl.bind("CTRL + Right",        hl.dsp.focus({ workspace = "e+1" }))
hl.bind("CTRL + SUPER + Left",  hl.dsp.window.move({ workspace = "-1", follow = true }))
hl.bind("CTRL + SUPER + Right", hl.dsp.window.move({ workspace = "+1", follow = true }))

for i = 1, 9 do
    hl.bind("CTRL + " .. i, hl.dsp.focus({ workspace = i }))                          -- view
    hl.bind("ALT + "  .. i, hl.dsp.window.move({ workspace = i, follow = true }))     -- tag + follow
end

-- monitors
pcall(function()
    hl.bind("ALT + SHIFT + Left",   hl.dsp.focus({ monitor = "l" }))
    hl.bind("ALT + SHIFT + Right",  hl.dsp.focus({ monitor = "r" }))
end)
hl.bind("SUPER + ALT + Left",  hl.dsp.window.move({ monitor = "l" }))
hl.bind("SUPER + ALT + Right", hl.dsp.window.move({ monitor = "r" }))

-- gaps (mango incgaps / togglegaps)
local gi, go, gaps_on = 3, 12, true
local function apply_gaps()
    hl.config({ general = { gaps_in = gaps_on and gi or 0, gaps_out = gaps_on and go or 0 } })
end
hl.bind("ALT + SHIFT + x", function() gi, go = gi + 1, go + 1; apply_gaps() end)
hl.bind("ALT + SHIFT + z", function() gi, go = math.max(gi - 1, 0), math.max(go - 1, 0); apply_gaps() end)
hl.bind("ALT + SHIFT + r", function() gaps_on = not gaps_on; apply_gaps() end)

-- movewin / resizewin by 50px
local steps = {
    Up = { 0, -50 }, Down = { 0, 50 }, Left = { -50, 0 }, Right = { 50, 0 },
}
for key, s in pairs(steps) do
    hl.bind("CTRL + SHIFT + " .. key, hl.dsp.window.move({ x = s[1], y = s[2], relative = true }), { repeating = true })
    hl.bind("CTRL + ALT + "   .. key, hl.dsp.window.resize({ x = s[1], y = s[2], relative = true }), { repeating = true })
end

-- media keys (bonus, not in mango config)
hl.bind("XF86AudioRaiseVolume",  hl.dsp.exec_cmd("wpctl set-volume -l 1 @DEFAULT_AUDIO_SINK@ 5%+"), { locked = true, repeating = true })
hl.bind("XF86AudioLowerVolume",  hl.dsp.exec_cmd("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-"),      { locked = true, repeating = true })
hl.bind("XF86AudioMute",         hl.dsp.exec_cmd("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle"),     { locked = true })
hl.bind("XF86MonBrightnessUp",   hl.dsp.exec_cmd("brightnessctl set 5%+"),                          { locked = true, repeating = true })
hl.bind("XF86MonBrightnessDown", hl.dsp.exec_cmd("brightnessctl set 5%-"),                          { locked = true, repeating = true })
