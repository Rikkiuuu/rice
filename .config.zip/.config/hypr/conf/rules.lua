-- Window + layer rules

-- Ignore maximize requests from apps
hl.window_rule({
    name  = "suppress-maximize-events",
    match = { class = ".*" },
    suppress_event = "maximize",
})

-- shadow_only_floating=1: no shadows on tiled windows
hl.window_rule({
    name  = "shadow-only-floating",
    match = { float = false },
    no_shadow = true,
})

-- Layer rules (launchers, bars, popups). Adjust namespaces to match your shell:
-- check with `hyprctl layers`.
hl.layer_rule({
    name  = "rofi",
    match = { namespace = "^rofi$" },
    animation    = "popin 50%",
    blur         = true,
    ignore_alpha = 0.3,
})

hl.layer_rule({
    name  = "noctalia-blur",
    match = { namespace = "^noctalia.*" },
    blur         = true,   -- blur_layer=1
    ignore_alpha = 0.3,
})

-- Fullscreen windows opaque (video, games); every other app stays blurred/transparent
pcall(hl.window_rule, {
    name   = "fullscreen-opaque",
    match  = { fullscreen = true },
    opaque = true,
})
