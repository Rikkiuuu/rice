-- Window effects: blur on every app, shadows, rounding, opacity, dim
-- Blur only shows through transparent windows, so opacity is applied to ALL windows.
-- Lower active_opacity / inactive_opacity for more see-through glass, raise for less.

hl.config({
    decoration = {
        rounding         = 12,
        active_opacity   = 0.88,
        inactive_opacity = 0.78,

        dim_inactive = true,
        dim_strength = 0.12,

        blur = {
            enabled           = true,
            size              = 10,
            passes            = 3,
            noise             = 0.02,
            brightness        = 0.9,
            contrast          = 0.9,
            vibrancy          = 0.25,
            vibrancy_darkness = 0.3,
            new_optimizations = true,
            xray              = false, -- floating windows blur what's behind them too
            popups            = true,  -- menus / tooltips blurred
            popups_ignorealpha = 0.2,
        },

        shadow = {
            enabled      = true,
            range        = 16,
            render_power = 3,
            color        = 0x99000000, -- 0xAARRGGBB
        },
    },
})

-- Kept separate so a rejected value can't abort the rest of this file.
pcall(hl.config, { decoration = { shadow = { offset = "0 6" } } })
