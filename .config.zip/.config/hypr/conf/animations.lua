-- macOS-style spring animations.
-- Springs: mass / stiffness / dampening. Critical damping = 2*sqrt(stiffness*mass),
-- so dampening a bit below that gives the small, soft overshoot macOS has.

hl.config({ animations = { enabled = true } })

-- open / close: lively, tiny overshoot
hl.curve("macOpen",  { type = "spring", mass = 1, stiffness = 220, dampening = 21 })
-- move / resize: nearly critically damped, glides and settles
hl.curve("macMove",  { type = "spring", mass = 1, stiffness = 170, dampening = 25 })
-- workspace swipe: soft and heavy
hl.curve("macSpace", { type = "spring", mass = 1.1, stiffness = 130, dampening = 26 })
-- layers (bar, launcher, popups)
hl.curve("macLayer", { type = "spring", mass = 1, stiffness = 260, dampening = 24 })

-- fades and borders stay on plain curves (springs don't suit opacity)
hl.curve("macFade",  { type = "bezier", points = { {0.25, 0.1}, {0.25, 1} } })
hl.curve("macClose", { type = "bezier", points = { {0.4, 0},    {1, 1}    } })

hl.animation({ leaf = "global",      enabled = true, speed = 5,   bezier = "macFade" })

hl.animation({ leaf = "windowsIn",   enabled = true, speed = 5,   spring = "macOpen",  style = "popin 80%" })
hl.animation({ leaf = "windowsOut",  enabled = true, speed = 3.2, bezier = "macClose", style = "popin 85%" })
hl.animation({ leaf = "windowsMove", enabled = true, speed = 5,   spring = "macMove" })
hl.animation({ leaf = "windows",     enabled = true, speed = 5,   spring = "macMove" })

hl.animation({ leaf = "fadeIn",      enabled = true, speed = 3.5, bezier = "macFade" })
hl.animation({ leaf = "fadeOut",     enabled = true, speed = 3,   bezier = "macFade" })
hl.animation({ leaf = "border",      enabled = true, speed = 4,   bezier = "macFade" })

hl.animation({ leaf = "workspaces",  enabled = true, speed = 5,   spring = "macSpace", style = "slide" })

hl.animation({ leaf = "layersIn",    enabled = true, speed = 4.5, spring = "macLayer", style = "popin 85%" })
hl.animation({ leaf = "layersOut",   enabled = true, speed = 3,   bezier = "macClose", style = "popin 90%" })
