-- ~/.config/hypr/hyprland.lua
-- Modular layout (same idea as mango's config.conf): one file per concern in conf/.
-- Comment out a line to disable that module.
-- Each require() runs in its own scope, so a typo in one module won't kill the rest.

require("conf.autostart")
require("conf.effects")
require("conf.animations")
require("conf.appearance")
require("conf.layouts")
require("conf.input")
require("conf.behavior")
require("conf.rules")
require("conf.binds")
require("conf.binds-mouse")
