{ pkgs, inputs, username, hostname, ... }:

let
  system = pkgs.stdenv.hostPlatform.system;
in
{
  nix.settings = {
    experimental-features = [ "nix-command" "flakes" ];
    # Hyprland binary cache (avoids compiling it)
    substituters = [ "https://hyprland.cachix.org" ];
    trusted-public-keys = [ "hyprland.cachix.org-1:a7pgxzMz7+chwVL3/pzj6jIBMioiJM7ypFP8PwtkuGc=" ];
  };
  nixpkgs.config.allowUnfree = true;

  # ── boot / host ───────────────────────────────────────────
  boot.loader.limine = {
    enable = true;
    maxGenerations = 5;
  };
  boot.loader.efi.canTouchEfiVariables = true;
  networking.hostName = hostname;
  networking.networkmanager.enable = true;
  time.timeZone = "Asia/Jakarta";
  i18n.defaultLocale = "en_US.UTF-8";

  users.users.${username} = {
    isNormalUser = true;
    extraGroups = [ "wheel" "networkmanager" "video" "audio" ];
    shell = pkgs.fish;
  };

  # ── compositors (pick one at the login screen / TTY) ──────
  programs.hyprland = {
    enable = true;
    package = inputs.hyprland.packages.${system}.hyprland;
    portalPackage = inputs.hyprland.packages.${system}.xdg-desktop-portal-hyprland;
  };
  programs.mango.enable = true;
  programs.fish.enable = true;

  # Login screen: ly (lists Hyprland + mango sessions)
  services.displayManager.ly.enable = true;

  # ── audio / bluetooth / power / misc services ─────────────
  security.rtkit.enable = true;
  services.pipewire = {
    enable = true;
    alsa.enable = true;
    pulse.enable = true;
  };
  hardware.bluetooth.enable = true;
  services.upower.enable = true;
  services.power-profiles-daemon.enable = true;
  services.gvfs.enable = true;     # Thunar trash / mounts
  services.tumbler.enable = true;  # Thunar thumbnails
  programs.thunar.enable = true;

  fonts.packages = with pkgs; [
    nerd-fonts.jetbrains-mono
    noto-fonts
    noto-fonts-color-emoji
  ];

  environment.systemPackages = with pkgs; [
    git
    vim
    wget
  ];

  system.stateVersion = "25.05"; # set to the release you first installed
}
