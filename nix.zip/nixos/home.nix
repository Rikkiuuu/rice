{ pkgs, inputs, username, lib, ... }:

let
  system = pkgs.stdenv.hostPlatform.system;
in
{
  home.username = username;
  home.homeDirectory = "/home/${username}";
  home.stateVersion = "25.05"; # keep equal to what you first installed with

  home.packages = (with pkgs; [
    # launcher / bar / terminal / files
    rofi
    waybar
    foot
    xfce.thunar
    fastfetch

    # used by the rofi / waybar scripts and keybinds
    jq
    imagemagick          # wallpaper-picker thumbnails
    swaybg
    awww                 # wallpaper-picker prefers this (swaybg is the fallback)
    libnotify
    playerctl
    pavucontrol
    networkmanagerapplet # nm-connection-editor
    brightnessctl
    wireplumber          # wpctl for volume keys
    hyprlock             # powermenu "Lock"
    wl-clipboard
  ]) ++ [
    inputs.noctalia.packages.${system}.default
  ];

  # ── fish: plugins from nixpkgs instead of fisher ────────────────────
  # ~/.config/fish is intentionally NOT symlinked: tide/fisher write universal
  # variables (fish_variables) there and need a writable directory.
  programs.fish = {
    enable = true;
    plugins = with pkgs.fishPlugins; [
      { name = "tide";      src = tide.src; }
      { name = "autopair";  src = autopair.src; }
      { name = "fzf-fish";  src = fzf-fish.src; }
      { name = "pisces";    src = pisces.src; }
    ];
  };
  programs.fzf.enable = true;
  programs.fd.enable = true;
  programs.bat.enable = true;

  # ── dotfiles ────────────────────────────────────────────────────────
  # The repo's ./config/.config/<app> folders are linked into ~/.config.
  # Out-of-store symlinks would let you edit live; plain `source` keeps it pure.
  xdg.configFile = {
    "hypr".source    = ./config/.config/hypr;
    "mango".source   = ./config/.config/mango;
    "waybar".source  = ./config/.config/waybar;
    "rofi".source    = ./config/.config/rofi;
    "foot".source    = ./config/.config/foot;
    "fastfetch".source = ./config/.config/fastfetch;
    "xfce4/xfconf/xfce-perchannel-xml/thunar.xml".source =
      ./config/.config/xfce4/xfconf/xfce-perchannel-xml/thunar.xml;
    "gtk-3.0/bookmarks".source = ./config/.config/gtk-3.0/bookmarks;
  };

  programs.home-manager.enable = true;
}
