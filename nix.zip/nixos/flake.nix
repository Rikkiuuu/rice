{
  description = "witnix — NixOS + Home Manager (Hyprland, mango, Noctalia)";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";

    home-manager = {
      url = "github:nix-community/home-manager";
      inputs.nixpkgs.follows = "nixpkgs";
    };

    # Your dotfiles use the Lua config (hyprland.lua), which needs a very recent
    # Hyprland. Pull it from upstream rather than nixpkgs so it's always new enough.
    hyprland.url = "github:hyprwm/Hyprland";

    # mango (a.k.a. mangowc) compositor — provides nixosModules / hmModules
    mango = {
      url = "github:DreamMaoMao/mangowc";
      inputs.nixpkgs.follows = "nixpkgs";
    };

    # Noctalia shell (autostarted by both compositors)
    noctalia = {
      url = "github:noctalia-dev/noctalia-shell";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  };

  outputs = { self, nixpkgs, home-manager, hyprland, mango, noctalia, ... }@inputs:
    let
      system = "x86_64-linux";
      username = "witnix";
      hostname = "nixos";
    in
    {
      nixosConfigurations.${hostname} = nixpkgs.lib.nixosSystem {
        inherit system;
        specialArgs = { inherit inputs username hostname; };

        modules = [
          # Generate with: nixos-generate-config --show-hardware-config > hardware-configuration.nix
          ./hardware-configuration.nix

          mango.nixosModules.mango
          home-manager.nixosModules.home-manager

          ./configuration.nix

          {
            home-manager = {
              useGlobalPkgs = true;
              useUserPackages = true;
              backupFileExtension = "hm-bak";
              extraSpecialArgs = { inherit inputs username; };
              users.${username} = import ./home.nix;
            };
          }
        ];
      };
    };
}
